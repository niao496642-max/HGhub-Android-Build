HGhub 1.2.0 —— 一加平板 Pro ARM64 APK 构建包

重要：这个压缩包是源码和自动构建配置，不是已经编译好的 APK。
需要上传到你自己的新 GitHub 仓库，再由 GitHub Actions 云端生成 APK。

操作：
1. 在 GitHub 新建一个私有仓库，不要上传到原作者仓库。
2. 解压本压缩包，把里面所有文件和文件夹上传到新仓库 main 分支，必须保留 .github/workflows/android-arm64-debug.yml 路径。
3. 打开仓库的 Actions 页面。
4. 选择 “Build HGhub APK for OnePlus Pad Pro”，点击 Run workflow。
5. 等待任务成功，打开运行记录，在 Artifacts 下载 HGhub_1.2.0_OnePlusPadPro_ARM64_debug。
6. 解压下载的产物 ZIP，里面就是 APK。把 APK 传到平板安装。

本构建目标为 aarch64（ARM64），适合一加平板 Pro。使用 Android 调试签名，不需要你提供签名证书或密码。
注意：源码许可证为 PolyForm Noncommercial，需遵守非商业使用条款。
如果平板已经安装了同包名但不同签名的 HGhub，Android 可能拒绝覆盖安装。先不要急着卸载旧版，避免丢失数据；把安装报错截图发来再处理。
